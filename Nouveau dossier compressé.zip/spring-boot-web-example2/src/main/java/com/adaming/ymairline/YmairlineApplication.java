package com.adaming.ymairline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YmairlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(YmairlineApplication.class, args);
	}

}
