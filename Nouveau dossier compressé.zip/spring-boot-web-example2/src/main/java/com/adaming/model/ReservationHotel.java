package com.adaming.model;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;

@Entity
public class ReservationHotel extends Hotel {
	
	
	private String dateEntre;
	
	private String dateSortie;
	
	@OneToOne(fetch=FetchType.LAZY, mappedBy="reservationHotel")
	private ReservationVol reservationVol;

	public ReservationHotel() {
		super();
		
	}

	public ReservationHotel(int idHotel, String dateEntre, String dateSortie) {
		super();
		
		this.dateEntre = dateEntre;
		this.dateSortie = dateSortie;
	}


	public String getDateEntre() {
		return dateEntre;
	}

	public void setDateEntre(String dateEntre) {
		this.dateEntre = dateEntre;
	}

	public String getDateSortie() {
		return dateSortie;
	}

	public void setDateSortie(String dateSortie) {
		this.dateSortie = dateSortie;
	}

	@Override
	public String toString() {
		return "ReservationHotel [dateEntre=" + dateEntre + ", dateSortie=" + dateSortie + "]";
	}
	
	
}